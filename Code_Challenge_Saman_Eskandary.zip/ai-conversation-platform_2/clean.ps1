# Force stop any running Node processes to release file locks
Write-Host "Stopping any running Node.js processes..." -ForegroundColor Yellow
Stop-Process -Name "node" -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 2

Write-Host "Cleaning up unnecessary files and dependencies..." -ForegroundColor Cyan

# Use Force and ErrorAction Stop to ensure deletion
 $dirsToDelete = @(
    "ai-service\node_modules",
    "backend\node_modules",
    "backend\dist",
    "frontend\node_modules",
    "frontend\.next"
)

foreach ($dir in $dirsToDelete) {
    if (Test-Path $dir) {
        Write-Host "Removing $dir..." -ForegroundColor Yellow
        Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        Write-Host "Skipped $dir (not found)..." -ForegroundColor DarkGray
    }
}

Write-Host "----------------------------------------" -ForegroundColor Cyan
Write-Host "Cleanup complete!" -ForegroundColor Green
Write-Host "Your project is now lightweight and ready to be zipped and sent." -ForegroundColor Green