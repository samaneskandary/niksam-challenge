# AI Conversation Platform

A minimal AI conversation platform designed to handle concurrent messages, guarantee order, and handle AI service failures.

## Tech Stack
- Frontend: React, Next.js, TypeScript, Tailwind CSS
- Backend: NestJS, TypeScript, Prisma ORM
- Database: PostgreSQL
- AI Service: Node.js, Express

## Prerequisites
- Node.js (v18 or higher)
- PostgreSQL

## Database Configuration
The project uses a single `.env` file located in the root directory to manage the database connection.
By default, it is configured to:
`DATABASE_URL="postgresql://postgres:passpass@localhost:8000/db?schema=public"`

If your PostgreSQL setup is different, simply open the `.env` file in the root folder and update the `DATABASE_URL` value before starting the backend.

## Setup and Installation

### 1. AI Service Setup
Open a terminal and run:

```bash
cd ai-service
npm install
npm start
```

The service will run on http://localhost:3001

### 2. Backend Setup
Open a new terminal and run:

```bash
cd backend
npm install
npx prisma migrate dev --name init
npm run start:dev
```

The backend will run on http://localhost:3000

### 3. Frontend Setup
Open a new terminal and run:

```bash
cd frontend
npm install
npm run dev
```

The frontend will run on http://localhost:3002

## Usage
1. Open http://localhost:3002 in your browser.
2. Click "New Chat".
3. Type a message and hit Enter.
4. If the AI fails to respond, use the "Retry" button.