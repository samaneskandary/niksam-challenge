﻿# AI Conversation Platform

A minimal AI conversation platform designed to handle concurrent messages, guarantee order, and handle AI service failures.

## Tech Stack
- Frontend: React, Next.js, TypeScript, Tailwind CSS
- Backend: NestJS, TypeScript, Prisma ORM
- Database: PostgreSQL
- AI Service: Node.js, Express

## Prerequisites
- Node.js (v18 or higher)
- PostgreSQL running on port 8000

## Setup and Installation

### 1. Database Setup
The backend expects the database connection string to be:
postgresql://postgres:passpass@localhost:8000/db?schema=public

Ensure your PostgreSQL instance is running on port 8000 with the database name db, user postgres, and password passpass.

### 2. AI Service Setup
Open a terminal and run:

```bash
cd ai-service
npm install
npm start
```

The service will run on http://localhost:3001

### 3. Backend Setup
Open a new terminal and run:

```bash
cd backend
npm install
npx prisma migrate dev --name init
npm run start:dev
```

The backend will run on http://localhost:3000

### 4. Frontend Setup
Open a new terminal and run:

```bash
cd frontend
npm install
npm run dev
```

The frontend will run on http://localhost:3002

## Usage
1. Open http://localhost:3002 in your browser.
2. Click "New Chat".
3. Type a message and hit Enter.
4. If the AI fails to respond, use the "Retry" button.