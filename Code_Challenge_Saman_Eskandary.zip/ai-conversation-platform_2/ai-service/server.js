const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.post('/generate', async (req, res) => {
    const { prompt, messageId } = req.body;
    const rand = Math.random();

    try {
        if (rand < 0.33) {
            return res.json({ response: `Response to: ${prompt}` });
        } else if (rand < 0.66) {
            await new Promise(r => setTimeout(r, 4000));
            return res.json({ response: `Slow response to: ${prompt}` });
        } else {
            return res.status(500).json({ error: 'AI Service Unavailable' });
        }
    } catch (err) {
        return res.status(500).json({ error: 'Internal AI Error' });
    }
});

app.listen(3001, () => console.log('AI Service running on port 3001'));
