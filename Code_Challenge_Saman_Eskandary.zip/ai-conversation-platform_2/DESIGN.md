﻿# Architecture and Design Document

## 1. System Overview
The system is composed of three isolated components communicating via HTTP/REST:
1. Frontend (Next.js): Handles UI, generates idempotency keys, and polls for pending messages.
2. Backend (NestJS): Business logic, strict ordering, and transactional safety.
3. AI Service (Express): Mock LLM returning random states (Success, Slow, Failure).

## 2. Architecture Diagram

```text
+----------------+       HTTP/REST        +----------------+       HTTP/REST        +----------------+
|                |  --------------------> |                |  --------------------> |                |
|  Frontend      |                        |  Backend       |                        |  AI Service    |
|  (Next.js)     |  <-------------------- |  (NestJS)      |  <-------------------- |  (Express)     |
|                |   Polling / Response   |                |   Async Response       |                |
+----------------+                        +-------+--------+                        +----------------+
                                                  |
                                          Connect via TCP
                                                  |
                                          +-------+--------+
                                          |                |
                                          |  PostgreSQL    |
                                          |                |
                                          +----------------+
```

## 3. Database Model
We use PostgreSQL with Prisma ORM. The schema is designed to enforce ordering and idempotency at the database level.

- Conversation: Has a counter field to track the sequence.
- Message: Has sequenceNumber for deterministic order, and idempotencyKey with a unique constraint.

```prisma
model Conversation {
  id        String    @id @default(uuid())
  title     String    @default("New Conversation")
  counter   Int       @default(0)
  createdAt DateTime  @default(now())
  updatedAt DateTime  @updatedAt
  messages  Message[]
}

model Message {
  id             String   @id @default(uuid())
  conversationId String
  conversation   Conversation @relation(fields: [conversationId], references: [id], onDelete: Cascade)
  role           String
  content        String
  sequenceNumber Int
  idempotencyKey String   @unique
  status         String   @default("completed")
  createdAt      DateTime @default(now())

  @@index([conversationId, sequenceNumber])
}
```

## 4. Message Flow and Concurrency Handling
Challenge: User sends Messages A, B, C concurrently. They arrive out of order, and AI responses finish out of order.

Solution:
1. When a user message request arrives, NestJS initiates a DB transaction.
2. It executes SELECT * FROM "Conversation" WHERE id = $1 FOR UPDATE; This places a row-level lock, forcing concurrent requests for the same conversation to queue.
3. It reads the counter (e.g., 0).
4. It assigns sequenceNumber = 1 to User Msg, and sequenceNumber = 2 to AI Msg.
5. It updates counter to 2 and commits.
6. The AI request is fired asynchronously.
7. Because sequences are assigned atomically before AI calls, out-of-order AI completion does not affect order.

## 5. Idempotency
Challenge: Client sends the same message twice due to network retries.

Solution:
- The frontend generates a UUID (idempotencyKey) for every message intent.
- The backend attempts to insert the message.
- Postgres enforces the unique constraint. If duplicate, Prisma throws P2002.
- Backend catches the error, queries the existing message, and returns it as 200 OK.

## 6. AI Failure Handling
Challenge: AI service fails, times out, or is slow.

Solution:
- AI Message is saved with status: "pending".
- If the HTTP request fails, backend updates status to "failed".
- Frontend polls every 2s. If it sees "failed", it renders a "Retry" button.
- Clicking Retry calls an endpoint that re-dispatches the AI request without changing the sequence number.

## 7. Tradeoffs and Future Scaling
1. Polling vs WebSockets: Chose HTTP polling for simplicity. In production, WebSockets/SSE would push updates instantly, reducing DB load.
2. Row Locking vs Event Sourcing: SELECT FOR UPDATE limits write throughput per conversation. For massive scale, an event-sourcing/Kafka approach appending to a partitioned log would allow higher concurrency.
3. Fire-and-Forget vs Job Queue: Backend dispatches AI request using an async Promise. If backend crashes, message stays "pending". In production, a robust job queue (BullMQ/Redis) would guarantee at-least-once processing.