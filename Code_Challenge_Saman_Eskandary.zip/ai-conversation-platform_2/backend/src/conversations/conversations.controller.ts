import { Controller, Post, Get, Patch, Body, Param } from '@nestjs/common';
import { ConversationsService } from './conversations.service';

@Controller('conversations')
export class ConversationsController {
  constructor(private readonly service: ConversationsService) {}

  @Post()
  create() {
    return this.service.createConversation();
  }

  @Get()
  findAll() {
    return this.service.getConversations();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.service.getConversationById(id);
  }

  @Patch(':id')
  updateTitle(
    @Param('id') id: string,
    @Body() body: { title: string },
  ) {
    return this.service.updateConversationTitle(id, body.title);
  }

  @Get(':id/messages')
  getMessages(@Param('id') id: string) {
    return this.service.getMessages(id);
  }

  @Post(':id/messages')
  sendMessage(
    @Param('id') id: string,
    @Body() body: { content: string; idempotencyKey: string },
  ) {
    return this.service.sendMessage(id, body.content, body.idempotencyKey);
  }

  @Post(':id/messages/:messageId/retry')
  retryMessage(@Param('id') id: string, @Param('messageId') messageId: string) {
    return this.service.retryMessage(id, messageId);
  }
}