import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Prisma } from '@prisma/client';
import axios from 'axios';

@Injectable()
export class ConversationsService {
  constructor(private prisma: PrismaService) {}

  async createConversation() {
    return this.prisma.conversation.create({ data: {} });
  }

  async getConversations() {
    return this.prisma.conversation.findMany({
      orderBy: { updatedAt: 'desc' },
    });
  }

  async getConversationById(id: string) {
    return this.prisma.conversation.findUnique({ where: { id } });
  }

  async updateConversationTitle(id: string, title: string) {
    return this.prisma.conversation.update({
      where: { id },
      data: { title },
    });
  }

  async getMessages(conversationId: string) {
    return this.prisma.message.findMany({
      where: { conversationId },
      orderBy: { sequenceNumber: 'asc' },
    });
  }

  async sendMessage(conversationId: string, content: string, idempotencyKey: string) {
    try {
      return await this.prisma.$transaction(async (tx) => {
        await tx.$queryRaw`SELECT * FROM "Conversation" WHERE id = ${conversationId} FOR UPDATE`;
        
        const conversation = await tx.conversation.findUnique({ where: { id: conversationId } });
        if (!conversation) throw new BadRequestException('Conversation not found');

        const userSeq = conversation.counter + 1;
        const aiSeq = conversation.counter + 2;

        await tx.conversation.update({
          where: { id: conversationId },
          data: { counter: aiSeq },
        });

        const userMessage = await tx.message.create({
          data: {
            conversationId,
            role: 'user',
            content,
            sequenceNumber: userSeq,
            idempotencyKey,
            status: 'completed',
          },
        });

        const aiMessage = await tx.message.create({
          data: {
            conversationId,
            role: 'assistant',
            content: '',
            sequenceNumber: aiSeq,
            idempotencyKey: `${idempotencyKey}-ai`,
            status: 'pending',
          },
        });

        this.processAiResponse(conversationId, aiMessage.id, content);

        return userMessage;
      });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
        return this.prisma.message.findUnique({ where: { idempotencyKey } });
      }
      throw e;
    }
  }

  private async processAiResponse(conversationId: string, aiMessageId: string, prompt: string) {
    try {
      const response = await axios.post('http://localhost:3001/generate', {
        prompt,
        messageId: aiMessageId,
      });
      
      await this.prisma.message.update({
        where: { id: aiMessageId },
        data: { content: response.data.response, status: 'completed' },
      });
    } catch (error) {
      await this.prisma.message.update({
        where: { id: aiMessageId },
        data: { content: '', status: 'failed' },
      });
    }
  }

  async retryMessage(conversationId: string, messageId: string) {
    const aiMessage = await this.prisma.message.findUnique({ where: { id: messageId } });
    if (!aiMessage || aiMessage.role !== 'assistant' || aiMessage.status !== 'failed') {
      throw new BadRequestException('Invalid message for retry');
    }

    const userMessage = await this.prisma.message.findFirst({
      where: { conversationId, sequenceNumber: aiMessage.sequenceNumber - 1 },
    });

    await this.prisma.message.update({
      where: { id: messageId },
      data: { status: 'pending' },
    });

    this.processAiResponse(conversationId, messageId, userMessage.content);
  }
}