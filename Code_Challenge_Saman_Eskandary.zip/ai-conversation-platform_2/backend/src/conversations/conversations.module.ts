import { Module } from '@nestjs/common';
import { ConversationsController } from './conversations.controller';
import { ConversationsService } from './conversations.service';
import { PrismaModule } from '../prisma/prisma.module'; // این خط اضافه شود

@Module({
  imports: [PrismaModule], // این خط اضافه شود
  controllers: [ConversationsController],
  providers: [ConversationsService],
})
export class ConversationsModule {}