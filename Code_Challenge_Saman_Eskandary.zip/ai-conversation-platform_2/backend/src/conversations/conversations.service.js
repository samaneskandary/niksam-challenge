"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const client_1 = require("@prisma/client");
const axios_1 = require("axios");
let ConversationsService = class ConversationsService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async createConversation() {
        return this.prisma.conversation.create({ data: {} });
    }
    async getConversations() {
        return this.prisma.conversation.findMany({
            orderBy: { updatedAt: 'desc' },
        });
    }
    async getMessages(conversationId) {
        return this.prisma.message.findMany({
            where: { conversationId },
            orderBy: { sequenceNumber: 'asc' },
        });
    }
    async sendMessage(conversationId, content, idempotencyKey) {
        try {
            return await this.prisma.$transaction(async (tx) => {
                await tx.$queryRaw `SELECT * FROM "Conversation" WHERE id = ${conversationId} FOR UPDATE`;
                const conversation = await tx.conversation.findUnique({ where: { id: conversationId } });
                if (!conversation)
                    throw new common_1.BadRequestException('Conversation not found');
                const userSeq = conversation.counter + 1;
                const aiSeq = conversation.counter + 2;
                await tx.conversation.update({
                    where: { id: conversationId },
                    data: { counter: aiSeq },
                });
                const userMessage = await tx.message.create({
                    data: {
                        conversationId,
                        role: 'user',
                        content,
                        sequenceNumber: userSeq,
                        idempotencyKey,
                        status: 'completed',
                    },
                });
                const aiMessage = await tx.message.create({
                    data: {
                        conversationId,
                        role: 'assistant',
                        content: '',
                        sequenceNumber: aiSeq,
                        idempotencyKey: `${idempotencyKey}-ai`,
                        status: 'pending',
                    },
                });
                this.processAiResponse(conversationId, aiMessage.id, content);
                return userMessage;
            });
        }
        catch (e) {
            if (e instanceof client_1.Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
                return this.prisma.message.findUnique({ where: { idempotencyKey } });
            }
            throw e;
        }
    }
    async processAiResponse(conversationId, aiMessageId, prompt) {
        try {
            const response = await axios_1.default.post('http://localhost:3001/generate', {
                prompt,
                messageId: aiMessageId,
            });
            await this.prisma.message.update({
                where: { id: aiMessageId },
                data: { content: response.data.response, status: 'completed' },
            });
        }
        catch (error) {
            await this.prisma.message.update({
                where: { id: aiMessageId },
                data: { content: '', status: 'failed' },
            });
        }
    }
    async retryMessage(conversationId, messageId) {
        const aiMessage = await this.prisma.message.findUnique({ where: { id: messageId } });
        if (!aiMessage || aiMessage.role !== 'assistant' || aiMessage.status !== 'failed') {
            throw new common_1.BadRequestException('Invalid message for retry');
        }
        const userMessage = await this.prisma.message.findFirst({
            where: { conversationId, sequenceNumber: aiMessage.sequenceNumber - 1 },
        });
        await this.prisma.message.update({
            where: { id: messageId },
            data: { status: 'pending' },
        });
        this.processAiResponse(conversationId, messageId, userMessage.content);
    }
};
exports.ConversationsService = ConversationsService;
exports.ConversationsService = ConversationsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ConversationsService);
