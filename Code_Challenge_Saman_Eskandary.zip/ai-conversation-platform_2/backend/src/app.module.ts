import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { ConversationsModule } from './conversations/conversations.module';

@Module({
  imports: [PrismaModule, ConversationsModule],
})
export class AppModule {}
