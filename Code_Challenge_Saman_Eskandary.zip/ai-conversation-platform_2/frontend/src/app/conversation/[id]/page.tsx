'use client';
import { useEffect, useState, useRef } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';

export default function Conversation() {
  const params = useParams();
  const id = params.id as string;
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  
  // Title editing states
  const [title, setTitle] = useState('AI Assistant');
  const [isEditing, setIsEditing] = useState(false);
  const [tempTitle, setTempTitle] = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);

  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isAtBottom, setIsAtBottom] = useState(true); // Track if user is at bottom

  const fetchMessages = async () => {
    try {
      const res = await fetch(`http://localhost:3000/conversations/${id}/messages`);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data);
      if (!data.some((m: any) => m.status === 'pending')) {
        if (pollingRef.current) clearInterval(pollingRef.current);
      }
    } catch (err) {
      console.error('Failed to fetch messages', err);
    }
  };

  const fetchConversation = async () => {
    try {
      const res = await fetch(`http://localhost:3000/conversations/${id}`);
      if (res.ok) {
        const data = await res.json();
        if (data.title) setTitle(data.title);
      }
    } catch (err) {
      console.error('Failed to fetch conversation', err);
    }
  };

  useEffect(() => {
    fetchConversation();
    fetchMessages();
    return () => {
      if (pollingRef.current) clearInterval(pollingRef.current);
    };
  }, [id]);

  // Smart Auto-scroll: only scroll if user is already at bottom
  useEffect(() => {
    if (isAtBottom && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isAtBottom]);

  // Focus input when editing starts
  useEffect(() => {
    if (isEditing && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [isEditing]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    const bottom = target.scrollHeight - target.scrollTop <= target.clientHeight + 50; // 50px tolerance
    setIsAtBottom(bottom);
  };

  const handleSaveTitle = async () => {
    const newTitle = tempTitle.trim() || 'Untitled Chat';
    setIsEditing(false);
    
    if (newTitle === title) return;

    try {
      await fetch(`http://localhost:3000/conversations/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newTitle }),
      });
      setTitle(newTitle);
    } catch (err) {
      alert('Failed to update title');
    }
  };

  const send = async () => {
    if (!input.trim()) return;
    const content = input;
    setInput('');
    const idempotencyKey = crypto.randomUUID(); 
    try {
      await fetch(`http://localhost:3000/conversations/${id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, idempotencyKey }),
      });
      setIsAtBottom(true); // Force scroll to bottom when sending new message
      fetchMessages();
      pollingRef.current = setInterval(fetchMessages, 2000);
    } catch (err) {
      alert('Failed to send message');
    }
  };

  const retry = async (messageId: string) => {
    try {
      await fetch(`http://localhost:3000/conversations/${id}/messages/${messageId}/retry`, { method: 'POST' });
      fetchMessages();
      pollingRef.current = setInterval(fetchMessages, 2000);
    } catch (err) {
      alert('Failed to retry message');
    }
  };

  // Helper to format time
  const formatTime = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <main className="h-screen flex items-center justify-center p-0 md:p-6">
      <div className="w-full max-w-5xl h-full md:h-[90vh] bg-white rounded-none md:rounded-2xl shadow-xl border border-slate-200 flex flex-col overflow-hidden">
        
        {/* Header Panel */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white">
          <Link href="/" className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600 transition-colors font-medium">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            Back
          </Link>
          
          <div className="flex-1 flex justify-center px-4">
            {isEditing ? (
              <input
                ref={editInputRef}
                value={tempTitle}
                onChange={(e) => setTempTitle(e.target.value)}
                onBlur={handleSaveTitle}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveTitle();
                  if (e.key === 'Escape') setIsEditing(false);
                }}
                className="text-lg font-bold text-slate-800 text-center bg-slate-100 border border-indigo-400 rounded-md px-2 py-0.5 outline-none focus:ring-2 focus:ring-indigo-100 w-full max-w-xs"
              />
            ) : (
              <button 
                onClick={() => {
                  setTempTitle(title);
                  setIsEditing(true);
                }}
                className="flex items-center gap-2 text-lg font-bold text-slate-700 cursor-pointer hover:text-indigo-600 hover:bg-indigo-50 px-3 py-1.5 rounded-md transition-all group max-w-xs"
                title="Click to edit title"
              >
                <span className="truncate">{title}</span>
                <svg className="w-4 h-4 text-slate-400 group-hover:text-indigo-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              </button>
            )}
          </div>

          <div className="w-12"></div>
        </div>

        {/* Messages Panel */}
        <div ref={scrollRef} onScroll={handleScroll} className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mb-4 border border-indigo-200 shadow-sm">
                <svg className="w-8 h-8 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                </svg>
              </div>
              <h3 className="text-md font-semibold text-slate-700">How can I help you today?</h3>
              <p className="text-xs text-slate-400 mt-1">Send a message to start the conversation.</p>
            </div>
          ) : (
            messages.map((m: any) => (
              <div key={m.id} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`max-w-[75%] px-4 py-2.5 rounded-xl text-sm transition-all ${
                  m.role === 'user' 
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-br-sm shadow-md' 
                    : m.status === 'failed'
                    ? 'bg-red-50 text-red-700 border border-red-200 rounded-bl-sm'
                    : 'bg-white text-slate-700 border border-slate-200 rounded-bl-sm shadow-sm'
                }`}>
                  {m.status === 'pending' ? (
                    <div className="flex items-center gap-2 py-1 text-slate-400">
                      <div className="flex gap-1">
                        <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce"></span>
                        <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></span>
                        <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></span>
                      </div>
                      <span className="text-xs">Thinking...</span>
                    </div>
                  ) : (
                    <p className="leading-relaxed">{m.content}</p>
                  )}
                  
                  {m.status === 'failed' && (
                    <button onClick={() => retry(m.id)} className="mt-2 text-xs text-red-500 font-medium underline hover:text-red-700 flex items-center gap-1">
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                      </svg>
                      Retry
                    </button>
                  )}
                </div>
                {/* Timestamp below the message */}
                <span className={`text-[10px] text-slate-400 mt-1 px-1 ${m.role === 'user' ? 'text-right' : 'text-left'}`}>
                  {formatTime(m.createdAt)}
                </span>
              </div>
            ))
          )}
        </div>

        {/* Input Panel */}
        <div className="p-4 bg-white border-t border-slate-200">
          <div className="flex gap-2 items-center">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              className="flex-1 bg-slate-50 border border-slate-200 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 focus:outline-none rounded-xl px-4 py-3 text-sm text-slate-800 placeholder-slate-400 transition-all"
              placeholder="Type your message here..."
            />
            <button 
              onClick={send} 
              disabled={!input.trim()}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:from-slate-300 disabled:to-slate-300 disabled:cursor-not-allowed text-white p-3 rounded-xl transition-all shadow-md flex items-center justify-center"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}