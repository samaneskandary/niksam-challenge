'use client';
import { useEffect, useState, useRef } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';

export default function Conversation() {
  const params = useParams();
  const id = params.id as string;
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const pollingRef = useRef<NodeJS.Timeout>();
  const scrollRef = useRef<HTMLDivElement>(null);

  const fetchMessages = async () => {
    try {
      const res = await fetch(`http://localhost:3000/conversations/${id}/messages`);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data);
      if (!data.some((m: any) => m.status === 'pending')) {
        if (pollingRef.current) clearInterval(pollingRef.current);
      }
    } catch (err) {
      console.error('Failed to fetch messages', err);
    }
  };

  useEffect(() => {
    fetchMessages();
    return () => {
      if (pollingRef.current) clearInterval(pollingRef.current);
    };
  }, [id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const send = async () => {
    if (!input.trim()) return;
    const content = input;
    setInput('');
    const idempotencyKey = crypto.randomUUID(); 
    try {
      await fetch(`http://localhost:3000/conversations/${id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, idempotencyKey }),
      });
      fetchMessages();
      pollingRef.current = setInterval(fetchMessages, 2000);
    } catch (err) {
      alert('Failed to send message');
    }
  };

  const retry = async (messageId: string) => {
    try {
      await fetch(`http://localhost:3000/conversations/${id}/messages/${messageId}/retry`, { method: 'POST' });
      fetchMessages();
      pollingRef.current = setInterval(fetchMessages, 2000);
    } catch (err) {
      alert('Failed to retry message');
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-3xl h-[85vh] bg-white rounded-3xl shadow-xl border border-slate-100 flex flex-col overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-indigo-100 hover:text-white transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            Back
          </Link>
          <h1 className="text-xl font-bold text-white text-center flex-1">AI Assistant</h1>
          <div className="w-12"></div>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-slate-700">Start a conversation</h3>
              <p className="text-slate-400 text-sm mt-1">Send a message to begin chatting with the AI</p>
            </div>
          ) : (
            messages.map((m: any) => (
              <div key={m.id} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`max-w-[80%] p-4 rounded-2xl transition-all ${
                  m.role === 'user' 
                    ? 'bg-indigo-600 text-white rounded-br-sm' 
                    : m.status === 'failed'
                    ? 'bg-red-50 text-red-600 border border-red-100 rounded-bl-sm'
                    : 'bg-white text-slate-800 border border-slate-100 rounded-bl-sm shadow-sm'
                }`}>
                  {m.status === 'pending' ? (
                    <div className="flex items-center gap-2 text-slate-400">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce"></span>
                        <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></span>
                        <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></span>
                      </div>
                      <span className="text-xs">Thinking...</span>
                    </div>
                  ) : (
                    <p className="text-sm leading-relaxed">{m.content}</p>
                  )}
                  
                  {m.status === 'failed' && (
                    <button onClick={() => retry(m.id)} className="mt-2 text-xs text-red-500 font-medium underline hover:text-red-700 flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      </svg>
                      Retry
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-4 bg-white border-t border-slate-100">
          <div className="flex gap-3 items-center">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              className="flex-1 bg-slate-100 border border-slate-200 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 focus:outline-none rounded-2xl px-5 py-3 text-sm text-slate-800 placeholder-slate-400 transition-all"
              placeholder="Type your message here..."
            />
            <button onClick={send} disabled={!input.trim()} className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white p-3 rounded-2xl transition-all duration-200 shadow-md hover:shadow-indigo-200">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}
