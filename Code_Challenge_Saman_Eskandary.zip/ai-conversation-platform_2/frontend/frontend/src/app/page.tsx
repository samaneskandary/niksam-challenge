'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function Home() {
  const [conversations, setConversations] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3000/conversations')
      .then(res => res.json())
      .then(setConversations)
      .catch(err => console.error('Failed to load conversations', err));
  }, []);

  const createConversation = async () => {
    try {
      const res = await fetch('http://localhost:3000/conversations', { method: 'POST' });
      if (!res.ok) throw new Error('Failed to create');
      const data = await res.json();
      window.location.href = `/conversation/${data.id}`;
    } catch (err) {
      alert('Error creating conversation. Is the backend running?');
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-2xl flex flex-col gap-4">
        
        {/* Header Panel */}
        <div className="bg-white rounded-2xl shadow-soft border border-slate-200 p-6 flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold text-slate-900">AI Conversations</h1>
            <p className="text-sm text-slate-500 mt-1">Manage and start new chats</p>
          </div>
          <button 
            onClick={createConversation}
            className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium py-2.5 px-5 rounded-lg transition-colors shadow-sm flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
            </svg>
            New Chat
          </button>
        </div>

        {/* List Panel */}
        <div className="bg-white rounded-2xl shadow-soft border border-slate-200 overflow-hidden">
          <div className="border-b border-slate-100 px-6 py-4 bg-slate-50/50">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-500">Recent Conversations</h2>
          </div>
          <div className="divide-y divide-slate-100">
            {conversations.length === 0 ? (
              <div className="p-10 text-center text-slate-400 text-sm">
                No conversations yet. Click "New Chat" to start.
              </div>
            ) : (
              conversations.map((c: any) => (
                <Link href={`/conversation/${c.id}`} key={c.id}>
                  <div className="flex items-center justify-between p-4 hover:bg-slate-50 transition-colors cursor-pointer group">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 font-bold text-sm border border-indigo-100">
                        {c.title.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="font-medium text-slate-800 group-hover:text-indigo-600 transition-colors">{c.title}</h3>
                        <p className="text-xs text-slate-400 mt-0.5">{new Date(c.createdAt).toLocaleString()}</p>
                      </div>
                    </div>
                    <svg className="w-5 h-5 text-slate-300 group-hover:text-indigo-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>

      </div>
    </main>
  );
}
